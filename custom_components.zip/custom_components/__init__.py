"""Dummy init so that pytest works."""
